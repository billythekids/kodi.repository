# -*- coding: utf-8 -*-


class Parser:
    def get(self, response):
        category = []

        return category
