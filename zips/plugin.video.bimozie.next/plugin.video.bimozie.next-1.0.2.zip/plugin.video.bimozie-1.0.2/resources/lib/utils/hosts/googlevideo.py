# -*- coding: utf-8 -*-

def get_link(url, media):
    return str(url), 'Google Video'
